package tuan5bai8;

public class CDList {

	public boolean themCD(CD cd) {
		// TODO Auto-generated method stub
		return false;
	}

	public String getSoLuongCD() {
		// TODO Auto-generated method stub
		return null;
	}

	public String tongGiaThanh() {
		// TODO Auto-generated method stub
		return null;
	}

	public void sapXepTheoGiaThanh() {
		// TODO Auto-generated method stub
		
	}

	public void xuatDanhSach() {
		// TODO Auto-generated method stub
		
	}

}
